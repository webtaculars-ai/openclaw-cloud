const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const { ECSClient, RunTaskCommand } = require('@aws-sdk/client-ecs');

const dynamo = DynamoDBDocumentClient.from(new DynamoDBClient({ region: 'ap-south-1' }));
const ecs = new ECSClient({ region: 'ap-south-1' });

exports.handler = async (event) => {
  try {
    const userId = event.requestContext.authorizer.claims.sub;
    const agentId = event.pathParameters.id;

    if (!agentId) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ error: 'Agent ID is required' })
      };
    }

    // Get agent
    const result = await dynamo.send(new GetCommand({
      TableName: 'openclaw-agents',
      Key: { userId, agentId }
    }));

    if (!result.Item) {
      return {
        statusCode: 404,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ error: 'Agent not found' })
      };
    }

    const agent = result.Item;

    if (agent.status === 'running') {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ 
          error: 'Agent is already running',
          agentId,
          status: 'running'
        })
      };
    }

    // Check credits
    const credits = await dynamo.send(new GetCommand({
      TableName: 'openclaw-credits',
      Key: { userId }
    }));

    if (!credits.Item || credits.Item.balance < 500) {
      return {
        statusCode: 402,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ 
          error: 'Insufficient credits',
          details: 'You need at least $5 to start an agent',
          currentBalance: credits.Item?.balance || 0
        })
      };
    }

    // Start ECS task
    let taskArn = null;
    try {
      const taskResult = await ecs.send(new RunTaskCommand({
        cluster: process.env.ECS_CLUSTER || 'openclaw-cluster',
        taskDefinition: process.env.TASK_DEFINITION || 'openclaw-agent-task:2',
        launchType: 'FARGATE',
        networkConfiguration: {
          awsvpcConfiguration: {
            subnets: (process.env.VPC_SUBNETS || 'subnet-0c2a0a08183d6f1ba,subnet-05438a80236a5fbbc').split(','),
            securityGroups: [(process.env.SECURITY_GROUP || 'sg-0de636f62dbbec8f3')],
            assignPublicIp: 'ENABLED'
          }
        },
        overrides: {
          containerOverrides: [{
            name: 'openclaw-agent',
            environment: [
              { name: 'AGENT_ID', value: agentId },
              { name: 'USER_ID', value: userId },
              { name: 'TELEGRAM_BOT_TOKEN', value: agent.telegramBotToken },
              { name: 'MODEL', value: agent.model || 'claude-sonnet-4' }
            ]
          }]
        }
      }));

      if (taskResult.tasks && taskResult.tasks.length > 0) {
        taskArn = taskResult.tasks[0].taskArn;
      } else {
        throw new Error('No task returned from ECS');
      }
    } catch (ecsError) {
      console.error('ECS start error:', ecsError);
      return {
        statusCode: 500,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ 
          error: 'Failed to start agent',
          details: 'Could not start container. Please try again.',
          technicalDetails: ecsError.message
        })
      };
    }

    // Update agent status
    await dynamo.send(new UpdateCommand({
      TableName: 'openclaw-agents',
      Key: { userId, agentId },
      UpdateExpression: 'SET #status = :status, taskArn = :taskArn, lastActive = :lastActive',
      ExpressionAttributeNames: { '#status': 'status' },
      ExpressionAttributeValues: {
        ':status': 'running',
        ':taskArn': taskArn,
        ':lastActive': new Date().toISOString()
      }
    }));

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': 'https://openpaw.co',
        'Access-Control-Allow-Credentials': 'true'
      },
      body: JSON.stringify({
        agentId,
        status: 'running',
        taskArn,
        message: 'Agent started successfully!'
      })
    };

  } catch (error) {
    console.error('Error starting agent:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': 'https://openpaw.co',
        'Access-Control-Allow-Credentials': 'true'
      },
      body: JSON.stringify({ 
        error: 'Failed to start agent',
        details: 'An unexpected error occurred.',
        technicalDetails: error.message
      })
    };
  }
};
