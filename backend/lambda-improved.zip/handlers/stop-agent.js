const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const { ECSClient, StopTaskCommand } = require('@aws-sdk/client-ecs');

const dynamo = DynamoDBDocumentClient.from(new DynamoDBClient({ region: 'ap-south-1' }));
const ecs = new ECSClient({ region: 'ap-south-1' });

exports.handler = async (event) => {
  try {
    const userId = event.requestContext.authorizer.claims.sub;
    const agentId = event.pathParameters.id;

    if (!agentId) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ error: 'Agent ID is required' })
      };
    }

    // Get agent
    const result = await dynamo.send(new GetCommand({
      TableName: 'openclaw-agents',
      Key: { userId, agentId }
    }));

    if (!result.Item) {
      return {
        statusCode: 404,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ error: 'Agent not found' })
      };
    }

    const agent = result.Item;

    if (agent.status !== 'running') {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ 
          error: 'Agent is not running',
          details: `Current status: ${agent.status}`,
          agentId,
          status: agent.status
        })
      };
    }

    if (!agent.taskArn) {
      // Agent says running but no task ARN - just update DB
      await dynamo.send(new UpdateCommand({
        TableName: 'openclaw-agents',
        Key: { userId, agentId },
        UpdateExpression: 'SET #status = :status',
        ExpressionAttributeNames: { '#status': 'status' },
        ExpressionAttributeValues: { ':status': 'stopped' }
      }));

      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({
          agentId,
          status: 'stopped',
          message: 'Agent marked as stopped (no running task found)'
        })
      };
    }

    // Stop ECS task
    try {
      await ecs.send(new StopTaskCommand({
        cluster: process.env.ECS_CLUSTER || 'openclaw-cluster',
        task: agent.taskArn,
        reason: 'User requested stop'
      }));
    } catch (ecsError) {
      console.error('ECS stop error:', ecsError);
      
      // If task not found, that's okay - update DB anyway
      if (ecsError.name !== 'ResourceNotFoundException') {
        return {
          statusCode: 500,
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': 'https://openpaw.co',
            'Access-Control-Allow-Credentials': 'true'
          },
          body: JSON.stringify({ 
            error: 'Failed to stop agent',
            details: 'Could not stop container. It may have already stopped.',
            technicalDetails: ecsError.message
          })
        };
      }
    }

    // Update status
    await dynamo.send(new UpdateCommand({
      TableName: 'openclaw-agents',
      Key: { userId, agentId },
      UpdateExpression: 'SET #status = :status',
      ExpressionAttributeNames: { '#status': 'status' },
      ExpressionAttributeValues: { ':status': 'stopped' }
    }));

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': 'https://openpaw.co',
        'Access-Control-Allow-Credentials': 'true'
      },
      body: JSON.stringify({
        agentId,
        status: 'stopped',
        message: 'Agent stopped successfully'
      })
    };

  } catch (error) {
    console.error('Error stopping agent:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': 'https://openpaw.co',
        'Access-Control-Allow-Credentials': 'true'
      },
      body: JSON.stringify({ 
        error: 'Failed to stop agent',
        details: 'An unexpected error occurred.',
        technicalDetails: error.message
      })
    };
  }
};
