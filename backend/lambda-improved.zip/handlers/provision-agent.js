const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');
const { ECSClient, RunTaskCommand } = require('@aws-sdk/client-ecs');

const dynamo = DynamoDBDocumentClient.from(new DynamoDBClient({ region: 'ap-south-1' }));
const ecs = new ECSClient({ region: 'ap-south-1' });

// Validate Telegram bot token format
function isValidTelegramToken(token) {
  return /^\d+:[A-Za-z0-9_-]+$/.test(token);
}

exports.handler = async (event) => {
  try {
    const userId = event.requestContext.authorizer.claims.sub;
    const body = JSON.parse(event.body);
    const { telegramBotToken, model = 'claude-sonnet-4' } = body;

    // Validation
    if (!telegramBotToken) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ 
          error: 'Telegram bot token is required',
          details: 'Please provide a valid bot token from @BotFather'
        })
      };
    }

    if (!isValidTelegramToken(telegramBotToken)) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ 
          error: 'Invalid bot token format',
          details: 'Token should look like: 123456789:ABCdefGHI...'
        })
      };
    }

    // Check user has sufficient credits (minimum $5)
    const credits = await dynamo.send(new GetCommand({
      TableName: 'openclaw-credits',
      Key: { userId }
    }));

    const balance = credits.Item?.balance || 0;
    if (balance < 500) { // Less than $5
      return {
        statusCode: 402,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ 
          error: 'Insufficient credits',
          details: 'You need at least $5 in credits to provision an agent',
          currentBalance: balance,
          requiredBalance: 500
        })
      };
    }

    const agentId = `agent-${Date.now()}`;
    let taskArn = null;

    // Start ECS task
    console.log('Starting ECS task for agent:', agentId);
    try {
      const result = await ecs.send(new RunTaskCommand({
        cluster: process.env.ECS_CLUSTER || 'openclaw-cluster',
        taskDefinition: process.env.TASK_DEFINITION || 'openclaw-agent-task:2',
        launchType: 'FARGATE',
        networkConfiguration: {
          awsvpcConfiguration: {
            subnets: (process.env.VPC_SUBNETS || 'subnet-0c2a0a08183d6f1ba,subnet-05438a80236a5fbbc').split(','),
            securityGroups: [(process.env.SECURITY_GROUP || 'sg-0de636f62dbbec8f3')],
            assignPublicIp: 'ENABLED'
          }
        },
        overrides: {
          containerOverrides: [{
            name: 'openclaw-agent',
            environment: [
              { name: 'AGENT_ID', value: agentId },
              { name: 'USER_ID', value: userId },
              { name: 'TELEGRAM_BOT_TOKEN', value: telegramBotToken },
              { name: 'MODEL', value: model }
            ]
          }]
        }
      }));

      if (result.tasks && result.tasks.length > 0) {
        taskArn = result.tasks[0].taskArn;
        console.log('ECS task started:', taskArn);
      } else if (result.failures && result.failures.length > 0) {
        const failure = result.failures[0];
        throw new Error(`ECS task failed: ${failure.reason}`);
      }
    } catch (ecsError) {
      console.error('ECS Error:', ecsError);
      
      return {
        statusCode: 500,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ 
          error: 'Failed to start agent',
          details: 'Could not start container. Please try again or contact support.',
          technicalDetails: ecsError.message
        })
      };
    }

    // Store agent in DynamoDB
    await dynamo.send(new PutCommand({
      TableName: 'openclaw-agents',
      Item: {
        userId,
        agentId,
        telegramBotToken,
        model,
        status: taskArn ? 'running' : 'pending',
        taskArn,
        createdAt: new Date().toISOString(),
        lastActive: new Date().toISOString()
      }
    }));

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': 'https://openpaw.co',
        'Access-Control-Allow-Credentials': 'true'
      },
      body: JSON.stringify({
        agentId,
        status: taskArn ? 'running' : 'pending',
        taskArn,
        message: taskArn 
          ? 'Agent provisioned successfully! Your bot should be online in 30-60 seconds.'
          : 'Agent created but container is starting. Please wait a moment.'
      })
    };

  } catch (error) {
    console.error('Error provisioning agent:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': 'https://openpaw.co',
        'Access-Control-Allow-Credentials': 'true'
      },
      body: JSON.stringify({ 
        error: 'Failed to provision agent',
        details: 'An unexpected error occurred. Please try again.',
        technicalDetails: error.message
      })
    };
  }
};
