const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');
const { ECSClient, DescribeTasksCommand } = require('@aws-sdk/client-ecs');

const dynamo = DynamoDBDocumentClient.from(new DynamoDBClient({ region: 'ap-south-1' }));
const ecs = new ECSClient({ region: 'ap-south-1' });

exports.handler = async (event) => {
  try {
    const userId = event.requestContext.authorizer.claims.sub;
    const agentId = event.pathParameters.id;

    if (!agentId) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ error: 'Agent ID is required' })
      };
    }

    // Get agent from DynamoDB
    const result = await dynamo.send(new GetCommand({
      TableName: 'openclaw-agents',
      Key: { userId, agentId }
    }));

    if (!result.Item) {
      return {
        statusCode: 404,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': 'https://openpaw.co',
          'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify({ error: 'Agent not found' })
      };
    }

    const agent = result.Item;

    // If agent has a task ARN and status is running, check actual ECS status
    if (agent.taskArn && agent.status === 'running') {
      try {
        const tasks = await ecs.send(new DescribeTasksCommand({
          cluster: process.env.ECS_CLUSTER || 'openclaw-cluster',
          tasks: [agent.taskArn]
        }));

        if (tasks.tasks && tasks.tasks.length > 0) {
          const task = tasks.tasks[0];
          agent.ecsStatus = task.lastStatus;
          agent.desiredStatus = task.desiredStatus;
          
          // If ECS says stopped but DB says running, update DB
          if (task.lastStatus === 'STOPPED' && agent.status === 'running') {
            agent.status = 'stopped';
            agent.stoppedReason = task.stoppedReason || 'Task stopped';
          }
        }
      } catch (ecsError) {
        console.error('Error checking ECS status:', ecsError);
        // Continue anyway - return DB data even if ECS check fails
      }
    }

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': 'https://openpaw.co',
        'Access-Control-Allow-Credentials': 'true'
      },
      body: JSON.stringify({ agent })
    };

  } catch (error) {
    console.error('Error fetching agent:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': 'https://openpaw.co',
        'Access-Control-Allow-Credentials': 'true'
      },
      body: JSON.stringify({ 
        error: 'Failed to fetch agent details',
        message: error.message 
      })
    };
  }
};
