const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');
const { ECSClient, RunTaskCommand } = require('@aws-sdk/client-ecs');

const dynamo = DynamoDBDocumentClient.from(new DynamoDBClient({ region: 'ap-south-1' }));
const ecs = new ECSClient({ region: 'ap-south-1' });

exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': 'https://openpaw.co',
    'Access-Control-Allow-Credentials': 'true',
  };

  try {
    const userId = event.requestContext.authorizer.claims.sub;
    const { telegramBotToken, model = 'claude-sonnet-4' } = JSON.parse(event.body);

    // Check credits
    const credits = await dynamo.send(new GetCommand({
      TableName: 'openclaw-credits',
      Key: { userId }
    }));

    if (!credits.Item || credits.Item.balance < 500) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Insufficient credits. Need at least $5 to provision agent.' })
      };
    }

    // Create agent record
    const agentId = `agent-${Date.now()}`;
    const now = new Date().toISOString();

    // Start ECS task
    let taskArn = null;
    try {
      const task = await ecs.send(new RunTaskCommand({
        cluster: process.env.ECS_CLUSTER || 'openclaw-cluster',
        taskDefinition: process.env.TASK_DEFINITION || 'openclaw-agent-task',
        launchType: 'FARGATE',
        networkConfiguration: {
          awsvpcConfiguration: {
            subnets: (process.env.VPC_SUBNETS || '').split(','),
            securityGroups: [process.env.SECURITY_GROUP],
            assignPublicIp: 'ENABLED'
          }
        },
        overrides: {
          containerOverrides: [{
            name: 'openclaw-agent',
            environment: [
              { name: 'AGENT_ID', value: agentId },
              { name: 'USER_ID', value: userId },
              { name: 'TELEGRAM_BOT_TOKEN', value: telegramBotToken },
              { name: 'MODEL', value: model }
            ]
          }]
        }
      }));
      taskArn = task.tasks[0]?.taskArn;
    } catch (ecsError) {
      console.error('ECS Error:', ecsError);
      // Continue anyway - store agent even if ECS fails
    }

    await dynamo.send(new PutCommand({
      TableName: 'openclaw-agents',
      Item: {
        userId,
        agentId,
        telegramBotToken,
        model,
        status: taskArn ? 'running' : 'pending',
        taskArn,
        createdAt: now,
        lastActiveAt: now
      }
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        agentId,
        status: taskArn ? 'running' : 'pending',
        taskArn,
        message: taskArn ? 'Agent provisioned successfully!' : 'Agent created (ECS infrastructure pending)'
      })
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
