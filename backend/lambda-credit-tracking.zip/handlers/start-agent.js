const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const { ECSClient, RunTaskCommand } = require('@aws-sdk/client-ecs');

const dynamo = DynamoDBDocumentClient.from(new DynamoDBClient({ region: 'ap-south-1' }));
const ecs = new ECSClient({ region: 'ap-south-1' });

exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': 'https://openpaw.co',
    'Access-Control-Allow-Credentials': 'true',
  };

  try {
    const userId = event.requestContext.authorizer.claims.sub;
    const agentId = event.pathParameters.agentId;

    const agent = await dynamo.send(new GetCommand({
      TableName: 'openclaw-agents',
      Key: { userId, agentId }
    }));

    if (!agent.Item) {
      return { statusCode: 404, headers, body: JSON.stringify({ error: 'Agent not found' }) };
    }

    if (agent.Item.status === 'running') {
      return { statusCode: 200, headers, body: JSON.stringify({ status: 'already_running' }) };
    }

    // Start ECS task
    const task = await ecs.send(new RunTaskCommand({
      cluster: process.env.ECS_CLUSTER,
      taskDefinition: process.env.TASK_DEFINITION,
      launchType: 'FARGATE',
      networkConfiguration: {
        awsvpcConfiguration: {
          subnets: (process.env.VPC_SUBNETS || '').split(','),
          securityGroups: [process.env.SECURITY_GROUP],
          assignPublicIp: 'ENABLED'
        }
      },
      overrides: {
        containerOverrides: [{
          name: 'openclaw-agent',
          environment: [
            { name: 'AGENT_ID', value: agentId },
            { name: 'USER_ID', value: userId },
            { name: 'TELEGRAM_BOT_TOKEN', value: agent.Item.telegramBotToken },
            { name: 'MODEL', value: agent.Item.model }
          ]
        }]
      }
    }));

    const taskArn = task.tasks[0]?.taskArn;

    await dynamo.send(new UpdateCommand({
      TableName: 'openclaw-agents',
      Key: { userId, agentId },
      UpdateExpression: 'SET #status = :status, taskArn = :arn, lastActiveAt = :now',
      ExpressionAttributeNames: { '#status': 'status' },
      ExpressionAttributeValues: {
        ':status': 'running',
        ':arn': taskArn,
        ':now': new Date().toISOString()
      }
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ status: 'running', taskArn })
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
