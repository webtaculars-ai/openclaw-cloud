const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, QueryCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'ap-south-1' });
const dynamo = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': 'https://openpaw.co',
    'Access-Control-Allow-Credentials': 'true',
  };

  try {
    const userId = event.requestContext.authorizer.claims.sub;
    
    // Get credits balance
    const credits = await dynamo.send(new GetCommand({
      TableName: 'openclaw-credits',
      Key: { userId }
    }));

    // Get recent transactions
    const transactions = await dynamo.send(new QueryCommand({
      TableName: 'openclaw-transactions',
      IndexName: 'userId-createdAt-index',
      KeyConditionExpression: 'userId = :uid',
      ExpressionAttributeValues: { ':uid': userId },
      ScanIndexForward: false,
      Limit: 50
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        balance: credits.Item?.balance || 0,
        totalUsed: credits.Item?.totalUsed || 0,
        transactions: transactions.Items || []
      })
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
