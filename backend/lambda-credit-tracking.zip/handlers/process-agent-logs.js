const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand, PutCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');
const { ECSClient, StopTaskCommand } = require('@aws-sdk/client-ecs');
const zlib = require('zlib');

const dynamo = DynamoDBDocumentClient.from(new DynamoDBClient({ region: 'ap-south-1' }));
const ecs = new ECSClient({ region: 'ap-south-1' });

// Token pricing (example rates - adjust based on actual Bedrock pricing)
const PRICING = {
  'claude-sonnet-4': {
    input: 0.003,  // $0.003 per 1K input tokens
    output: 0.015  // $0.015 per 1K output tokens
  },
  'claude-opus-4': {
    input: 0.015,
    output: 0.075
  }
};

exports.handler = async (event) => {
  console.log('Processing agent logs for credit deduction...');
  
  // Parse CloudWatch Logs event
  const payload = Buffer.from(event.awslogs.data, 'base64');
  const parsed = JSON.parse(zlib.gunzipSync(payload).toString());
  
  console.log('Log group:', parsed.logGroup);
  console.log('Log events:', parsed.logEvents.length);
  
  for (const logEvent of parsed.logEvents) {
    const message = logEvent.message;
    
    // Look for token usage patterns in OpenClaw logs
    // Pattern: "tokens used: input=1234 output=567" or similar
    const tokenMatch = message.match(/tokens?.*input[=:\s]+(\d+).*output[=:\s]+(\d+)/i);
    
    if (tokenMatch) {
      const inputTokens = parseInt(tokenMatch[1]);
      const outputTokens = parseInt(tokenMatch[2]);
      
      // Extract agent ID from log stream
      const agentIdMatch = parsed.logStream.match(/agent-(\d+)/);
      if (!agentIdMatch) continue;
      
      const agentId = 'agent-' + agentIdMatch[1];
      
      // Get agent details to find user
      const agent = await dynamo.send(new GetCommand({
        TableName: 'openclaw-agents',
        Key: { agentId }
      }));
      
      if (!agent.Item) continue;
      
      const userId = agent.Item.userId;
      const model = agent.Item.model || 'claude-sonnet-4';
      const pricing = PRICING[model] || PRICING['claude-sonnet-4'];
      
      // Calculate cost in cents
      const inputCost = (inputTokens / 1000) * pricing.input * 100;
      const outputCost = (outputTokens / 1000) * pricing.output * 100;
      const totalCost = Math.ceil(inputCost + outputCost);
      
      console.log(`Deducting ${totalCost} cents for agent ${agentId} (${inputTokens} in, ${outputTokens} out)`);
      
      // Deduct credits (atomic operation)
      try {
        const result = await dynamo.send(new UpdateCommand({
          TableName: 'openclaw-credits',
          Key: { userId },
          UpdateExpression: 'SET balance = balance - :cost, totalUsed = totalUsed + :cost',
          ConditionExpression: 'balance >= :cost',
          ExpressionAttributeValues: { ':cost': totalCost },
          ReturnValues: 'ALL_NEW'
        }));
        
        // Log transaction
        await dynamo.send(new PutCommand({
          TableName: 'openclaw-transactions',
          Item: {
            txnId: `txn-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            userId,
            type: 'usage',
            amountCents: -totalCost,
            description: `Agent ${agentId}: ${inputTokens} input + ${outputTokens} output tokens`,
            agentId,
            createdAt: new Date().toISOString()
          }
        }));
        
        console.log(`New balance: ${result.Attributes.balance} cents`);
        
        // Check if balance is low or zero
        if (result.Attributes.balance === 0) {
          console.log(`Balance is ZERO - stopping agent ${agentId}`);
          
          // Stop the agent
          if (agent.Item.taskArn) {
            await ecs.send(new StopTaskCommand({
              cluster: 'openclaw-cluster',
              task: agent.Item.taskArn,
              reason: 'Credits depleted'
            }));
          }
          
          // Update agent status
          await dynamo.send(new UpdateCommand({
            TableName: 'openclaw-agents',
            Key: { userId, agentId },
            UpdateExpression: 'SET #status = :status',
            ExpressionAttributeNames: { '#status': 'status' },
            ExpressionAttributeValues: { ':status': 'stopped_no_credits' }
          }));
          
          console.log('Agent stopped due to zero balance');
        } else if (result.Attributes.balance < 500) { // Less than $5
          console.log(`Low balance warning: ${result.Attributes.balance} cents remaining`);
          // TODO: Send notification to user
        }
        
      } catch (error) {
        if (error.name === 'ConditionalCheckFailedException') {
          console.error(`Insufficient balance for ${userId} - stopping agent`);
          
          // Stop agent immediately
          if (agent.Item.taskArn) {
            await ecs.send(new StopTaskCommand({
              cluster: 'openclaw-cluster',
              task: agent.Item.taskArn,
              reason: 'Insufficient credits'
            }));
          }
          
          await dynamo.send(new UpdateCommand({
            TableName: 'openclaw-agents',
            Key: { userId, agentId },
            UpdateExpression: 'SET #status = :status',
            ExpressionAttributeNames: { '#status': 'status' },
            ExpressionAttributeValues: { ':status': 'stopped_no_credits' }
          }));
        } else {
          throw error;
        }
      }
    }
  }
  
  return { statusCode: 200, body: 'Processed' };
};
