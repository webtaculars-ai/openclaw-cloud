const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, QueryCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'ap-south-1' });
const dynamo = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': 'https://openpaw.co',
    'Access-Control-Allow-Credentials': 'true',
  };

  try {
    const userId = event.requestContext.authorizer.claims.sub;
    
    const result = await dynamo.send(new QueryCommand({
      TableName: 'openclaw-agents',
      KeyConditionExpression: 'userId = :uid',
      ExpressionAttributeValues: { ':uid': userId }
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ agents: result.Items || [] })
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
