const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const { ECSClient, StopTaskCommand } = require('@aws-sdk/client-ecs');

const dynamo = DynamoDBDocumentClient.from(new DynamoDBClient({ region: 'ap-south-1' }));
const ecs = new ECSClient({ region: 'ap-south-1' });

exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': 'https://openpaw.co',
    'Access-Control-Allow-Credentials': 'true',
  };

  try {
    const userId = event.requestContext.authorizer.claims.sub;
    const agentId = event.pathParameters.agentId;

    const agent = await dynamo.send(new GetCommand({
      TableName: 'openclaw-agents',
      Key: { userId, agentId }
    }));

    if (!agent.Item) {
      return { statusCode: 404, headers, body: JSON.stringify({ error: 'Agent not found' }) };
    }

    if (agent.Item.taskArn) {
      try {
        await ecs.send(new StopTaskCommand({
          cluster: process.env.ECS_CLUSTER,
          task: agent.Item.taskArn,
          reason: 'User requested stop'
        }));
      } catch (err) {
        console.error('ECS stop error:', err);
      }
    }

    await dynamo.send(new UpdateCommand({
      TableName: 'openclaw-agents',
      Key: { userId, agentId },
      UpdateExpression: 'SET #status = :status',
      ExpressionAttributeNames: { '#status': 'status' },
      ExpressionAttributeValues: { ':status': 'stopped' }
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ status: 'stopped' })
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
