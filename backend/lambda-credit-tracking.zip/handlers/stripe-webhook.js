"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const ulid_1 = require("ulid");
const stripe = __importStar(require("../services/stripe"));
const dynamo = __importStar(require("../services/dynamo"));
const types_1 = require("../types");
function response(statusCode, body) {
    return {
        statusCode,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    };
}
async function handler(event) {
    try {
        // Extract Stripe signature (case-insensitive header)
        const signature = event.headers['Stripe-Signature'] || event.headers['stripe-signature'];
        if (!signature) {
            return response(400, { error: 'Missing Stripe signature' });
        }
        // Verify webhook signature
        let stripeEvent;
        try {
            stripeEvent = stripe.constructWebhookEvent(event.body, signature);
        }
        catch (error) {
            console.error('Webhook signature verification failed:', error);
            return response(400, { error: 'Invalid signature' });
        }
        // Handle checkout.session.completed event
        if (stripeEvent.type === 'checkout.session.completed') {
            const session = stripeEvent.data.object;
            const userId = session.metadata.userId;
            const tier = session.metadata.tier;
            if (!userId || !tier) {
                console.error('Missing metadata in Stripe session:', session);
                return response(400, { error: 'Missing metadata' });
            }
            // Check if first purchase
            const existingCredits = await dynamo.getCredits(userId);
            const isFirstPurchase = !existingCredits || existingCredits.balanceCents === 0;
            let creditsToAdd;
            let transactionType;
            let description;
            if (isFirstPurchase && tier === 'starter') {
                // First purchase with starter tier = 2x bonus
                creditsToAdd = types_1.SIGNUP_BONUS_CENTS; // $10
                transactionType = 'signup_bonus';
                description = 'Welcome bonus: $5 payment → $10 credits (2x match)';
            }
            else {
                // Regular recharge
                const tierConfig = types_1.RECHARGE_TIERS[tier];
                creditsToAdd = tierConfig.creditsCents;
                transactionType = 'recharge';
                description = `${tier} tier recharge`;
            }
            // Initialize credits if first time
            if (!existingCredits) {
                await dynamo.initializeCredits(userId, 0);
            }
            // Add credits
            await dynamo.addCredits(userId, creditsToAdd);
            // Record transaction
            await dynamo.createTransaction({
                userId,
                txnId: (0, ulid_1.ulid)(),
                type: transactionType,
                amountCents: creditsToAdd,
                description,
                stripePaymentId: session.payment_intent,
                createdAt: new Date().toISOString(),
            });
            // Ensure user record exists
            const user = await dynamo.getUser(userId);
            if (!user) {
                await dynamo.createUser({
                    userId,
                    email: session.customer_email || 'unknown',
                    signupDate: new Date().toISOString(),
                });
            }
        }
        return response(200, { received: true });
    }
    catch (error) {
        console.error('Error processing webhook:', error);
        return response(500, { error: 'Internal server error', message: error.message });
    }
}
