exports.handler = async (event) => {
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': 'https://openpaw.co',
      'Access-Control-Allow-Credentials': 'true',
    },
    body: JSON.stringify({ 
      agentId: 'agent-stub-' + Date.now(),
      status: 'running',
      message: 'Stub implementation - full logic deploying soon'
    })
  };
};
