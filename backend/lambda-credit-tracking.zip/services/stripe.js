"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCheckoutSession = createCheckoutSession;
exports.constructWebhookEvent = constructWebhookEvent;
const stripe_1 = __importDefault(require("stripe"));
const stripe = new stripe_1.default(process.env.STRIPE_SECRET_KEY, {
    apiVersion: '2023-10-16',
});
const FRONTEND_URL = process.env.FRONTEND_URL;
const WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET;
async function createCheckoutSession(userId, amountCents, tier) {
    const session = await stripe.checkout.sessions.create({
        mode: 'payment',
        payment_method_types: ['card'],
        line_items: [
            {
                price_data: {
                    currency: 'usd',
                    product_data: {
                        name: `OpenClaw Credits - ${tier}`,
                    },
                    unit_amount: amountCents,
                },
                quantity: 1,
            },
        ],
        success_url: `${FRONTEND_URL}/dashboard?payment=success`,
        cancel_url: `${FRONTEND_URL}/billing?payment=cancelled`,
        metadata: {
            userId,
            tier,
        },
    });
    return session.url;
}
function constructWebhookEvent(body, signature) {
    return stripe.webhooks.constructEvent(body, signature, WEBHOOK_SECRET);
}
