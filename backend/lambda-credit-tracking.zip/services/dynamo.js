"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUser = createUser;
exports.getUser = getUser;
exports.createAgent = createAgent;
exports.getAgent = getAgent;
exports.updateAgentStatus = updateAgentStatus;
exports.updateAgentToken = updateAgentToken;
exports.getAgentsByUser = getAgentsByUser;
exports.getCredits = getCredits;
exports.initializeCredits = initializeCredits;
exports.addCredits = addCredits;
exports.createTransaction = createTransaction;
exports.getTransactions = getTransactions;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const USERS_TABLE = process.env.USERS_TABLE;
const AGENTS_TABLE = process.env.AGENTS_TABLE;
const CREDITS_TABLE = process.env.CREDITS_TABLE;
const TRANSACTIONS_TABLE = process.env.TRANSACTIONS_TABLE;
// Users
async function createUser(user) {
    await docClient.send(new lib_dynamodb_1.PutCommand({
        TableName: USERS_TABLE,
        Item: user,
    }));
}
async function getUser(userId) {
    const result = await docClient.send(new lib_dynamodb_1.GetCommand({
        TableName: USERS_TABLE,
        Key: { userId },
    }));
    return result.Item;
}
// Agents
async function createAgent(agent) {
    await docClient.send(new lib_dynamodb_1.PutCommand({
        TableName: AGENTS_TABLE,
        Item: agent,
    }));
}
async function getAgent(userId, agentId) {
    const result = await docClient.send(new lib_dynamodb_1.GetCommand({
        TableName: AGENTS_TABLE,
        Key: { userId, agentId },
    }));
    return result.Item;
}
async function updateAgentStatus(userId, agentId, status, taskArn) {
    await docClient.send(new lib_dynamodb_1.UpdateCommand({
        TableName: AGENTS_TABLE,
        Key: { userId, agentId },
        UpdateExpression: 'SET #status = :status, taskArn = :taskArn, lastActiveAt = :now',
        ExpressionAttributeNames: {
            '#status': 'status',
        },
        ExpressionAttributeValues: {
            ':status': status,
            ':taskArn': taskArn,
            ':now': new Date().toISOString(),
        },
    }));
}
async function updateAgentToken(userId, agentId, token) {
    await docClient.send(new lib_dynamodb_1.UpdateCommand({
        TableName: AGENTS_TABLE,
        Key: { userId, agentId },
        UpdateExpression: 'SET telegramBotToken = :token, lastActiveAt = :now',
        ExpressionAttributeValues: {
            ':token': token,
            ':now': new Date().toISOString(),
        },
    }));
}
async function getAgentsByUser(userId) {
    const result = await docClient.send(new lib_dynamodb_1.QueryCommand({
        TableName: AGENTS_TABLE,
        KeyConditionExpression: 'userId = :userId',
        ExpressionAttributeValues: {
            ':userId': userId,
        },
    }));
    return (result.Items || []);
}
// Credits
async function getCredits(userId) {
    const result = await docClient.send(new lib_dynamodb_1.GetCommand({
        TableName: CREDITS_TABLE,
        Key: { userId },
    }));
    return result.Item;
}
async function initializeCredits(userId, balanceCents) {
    await docClient.send(new lib_dynamodb_1.PutCommand({
        TableName: CREDITS_TABLE,
        Item: {
            userId,
            balanceCents,
            totalUsedCents: 0,
        },
    }));
}
async function addCredits(userId, amountCents) {
    await docClient.send(new lib_dynamodb_1.UpdateCommand({
        TableName: CREDITS_TABLE,
        Key: { userId },
        UpdateExpression: 'SET balanceCents = if_not_exists(balanceCents, :zero) + :amount',
        ExpressionAttributeValues: {
            ':zero': 0,
            ':amount': amountCents,
        },
    }));
}
// Transactions
async function createTransaction(txn) {
    await docClient.send(new lib_dynamodb_1.PutCommand({
        TableName: TRANSACTIONS_TABLE,
        Item: txn,
    }));
}
async function getTransactions(userId, limit = 50) {
    const result = await docClient.send(new lib_dynamodb_1.QueryCommand({
        TableName: TRANSACTIONS_TABLE,
        KeyConditionExpression: 'userId = :userId',
        ExpressionAttributeValues: {
            ':userId': userId,
        },
        Limit: limit,
        ScanIndexForward: false, // Most recent first
    }));
    return (result.Items || []);
}
