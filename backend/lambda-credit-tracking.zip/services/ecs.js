"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runAgentTask = runAgentTask;
exports.stopAgentTask = stopAgentTask;
exports.describeTask = describeTask;
const client_ecs_1 = require("@aws-sdk/client-ecs");
const client = new client_ecs_1.ECSClient({});
const ECS_CLUSTER = process.env.ECS_CLUSTER;
const TASK_DEFINITION = process.env.TASK_DEFINITION;
const VPC_SUBNETS = process.env.VPC_SUBNETS.split(',');
const SECURITY_GROUP = process.env.SECURITY_GROUP;
async function runAgentTask(params) {
    const command = new client_ecs_1.RunTaskCommand({
        cluster: ECS_CLUSTER,
        taskDefinition: TASK_DEFINITION,
        launchType: 'FARGATE',
        networkConfiguration: {
            awsvpcConfiguration: {
                subnets: VPC_SUBNETS,
                assignPublicIp: 'ENABLED',
                securityGroups: [SECURITY_GROUP],
            },
        },
        overrides: {
            containerOverrides: [
                {
                    name: 'agent',
                    environment: [
                        { name: 'AGENT_ID', value: params.agentId },
                        { name: 'USER_ID', value: params.userId },
                        { name: 'TELEGRAM_BOT_TOKEN', value: params.telegramBotToken },
                        { name: 'MODEL', value: params.model },
                    ],
                },
            ],
        },
    });
    const result = await client.send(command);
    if (!result.tasks || result.tasks.length === 0 || !result.tasks[0].taskArn) {
        throw new Error('Failed to start ECS task');
    }
    return result.tasks[0].taskArn;
}
async function stopAgentTask(taskArn) {
    await client.send(new client_ecs_1.StopTaskCommand({
        cluster: ECS_CLUSTER,
        task: taskArn,
        reason: 'User requested stop',
    }));
}
async function describeTask(taskArn) {
    const result = await client.send(new client_ecs_1.DescribeTasksCommand({
        cluster: ECS_CLUSTER,
        tasks: [taskArn],
    }));
    if (!result.tasks || result.tasks.length === 0) {
        return 'UNKNOWN';
    }
    return result.tasks[0].lastStatus || 'UNKNOWN';
}
