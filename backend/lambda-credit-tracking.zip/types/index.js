"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RECHARGE_TIERS = exports.SIGNUP_BONUS_CENTS = exports.DEFAULT_MODEL = void 0;
exports.DEFAULT_MODEL = "anthropic.claude-sonnet-4-5-20250929-v1:0";
exports.SIGNUP_BONUS_CENTS = 1000; // $10
exports.RECHARGE_TIERS = {
    starter: { amountCents: 500, creditsCents: 500 }, // $5 → $5
    builder: { amountCents: 1500, creditsCents: 1500 }, // $15 → $15
    pro: { amountCents: 5000, creditsCents: 5000 }, // $50 → $50
};
